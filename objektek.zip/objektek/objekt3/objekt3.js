  let fizetes = {
    Anna: 2100,
    Cecil: 1890,
    Emil: 2050,
    Gerald: 2920
  };

  let osszeg = 0;

  for (let szemely in fizetes) {
    console.log(szemely + " keresete: " + fizetes[szemely]);
    osszeg += fizetes[szemely];
  }

  console.log("Az össz kereset: " + osszeg);

  // Az alábbi rész a weboldalon történő kiíratásért felel
  let kiiras = document.createElement("p");
  kiiras.textContent = "Fizetések összege: " + osszeg;
  document.body.appendChild(kiiras);
