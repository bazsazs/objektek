const heroes = [
    { firstName: "Ahsoka", lastName: "Tano", job: "padawan" },
    { firstName: "Boba", lastName: "Fett", job: "fejvadász" },
    { firstName: "Han", lastName: "Solo", job: "csempész" },
    { firstName: "Leia", lastName: "Organa", job: "szenátor" },
    // Add new heroes here
    { firstName: "Luke", lastName: "Skywalker", job: "jedi" },
    { firstName: "Mace", lastName: "Windu", job: "jedi master" },
];

function renderHeroCard(hero) {
    return `
        <div class="hero-card">
            <h2>${hero.firstName} ${hero.lastName}</h2>
            <p>Job: ${hero.job}</p>
        </div>
    `;
}

function renderHeroes() {
    const container = document.body;
    heroes.forEach(hero => {
        container.innerHTML += renderHeroCard(hero);
    });
}

renderHeroes();