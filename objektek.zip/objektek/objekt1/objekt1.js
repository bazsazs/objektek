let user = {};

user.firstName = 'John';

user.lastName = 'Smith';

user.firstName = 'Paul';

delete user.firstName;

console.log(user);